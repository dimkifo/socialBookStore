<script setup>
import TheWelcome from '../components/TheWelcome.vue'
import MainHeader from '../components/MainHeader.vue'
</script>

<template>
  <main>
    <!-- <MainHeader/> -->
    <div class="bg-red-500">sdsd</div>
  </main>
</template>
