package com.example.socialBookStore.models;

public enum Role {

    USER,
    ADMIN
}
