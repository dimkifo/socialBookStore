package com.example.socialBookStore.dto;



public class JwtResponseDto {
    private String accessToken;

}