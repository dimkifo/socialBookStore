package com.example.socialBookStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialBookStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
